#!/usr/bin/env node
// Technical export only: extract atlas cells, remove transparent padding, encode losslessly.
// No recoloring, pixel repainting, background removal, or generative editing happens here.
const fs = require('node:fs/promises');
const path = require('node:path');
const sharp = require('sharp');
const ROOT = __dirname;
const groups = [
  { atlas:'world-markers.png', dir:'markers', prefix:'marker', cols:4, rows:3, ids:[
    'selection-ring','action-ready','request-incoming','request-waiting','talking','group-talking',
    'invite-person','unavailable','accepted','declined','expired','unread',
  ] },
  { atlas:'ui-frames.png', dir:'frames', prefix:'frame', cols:3, rows:1,
    ids:['action-menu','request-dialog','chat-panel'] },
  { atlas:'ui-controls.png', dir:'buttons', prefix:'button', cols:4, rows:4, ids:[
    'primary-default','primary-hover','primary-pressed','primary-disabled',
    'secondary-default','secondary-hover','secondary-pressed','secondary-disabled',
    'chat','invite','send','leave','close','minimize','expand','participants',
  ] },
];
const LABELS = {
  'selection-ring':'상대 선택 타원','action-ready':'행동 가능','request-incoming':'대화 요청 도착',
  'request-waiting':'승인 기다리는 중','talking':'대화 중','group-talking':'그룹 대화 중',
  'invite-person':'대화 상대 추가','unavailable':'대화 불가','accepted':'승인됨','declined':'거절됨',
  'expired':'요청 만료','unread':'새 메시지','action-menu':'대화 행동 메뉴','request-dialog':'요청 승인 창',
  'chat-panel':'오른쪽 대화창','primary-default':'기본 버튼 · 평상시','primary-hover':'기본 버튼 · 가리킴',
  'primary-pressed':'기본 버튼 · 누름','primary-disabled':'기본 버튼 · 비활성',
  'secondary-default':'보조 버튼 · 평상시','secondary-hover':'보조 버튼 · 가리킴',
  'secondary-pressed':'보조 버튼 · 누름','secondary-disabled':'보조 버튼 · 비활성',
  'chat':'대화','invite':'사람 추가','send':'보내기','leave':'나가기','close':'닫기',
  'minimize':'접기','expand':'펼치기','participants':'참여자',
};

function alphaBounds(data, info) {
  let minX=info.width,minY=info.height,maxX=-1,maxY=-1,opaque=0,transparent=0,edge=0;
  const c=info.channels;
  for(let y=0;y<info.height;y++) for(let x=0;x<info.width;x++) {
    const a=data[(y*info.width+x)*c+c-1];
    if(a===0) transparent++;
    // Very faint alpha 1–7 is generator padding. Bounds follow visible alpha;
    // extraction preserves every original pixel inside the padded rectangle.
    if(a>=8){minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);}
    if(a>=240) opaque++;
    if((x<3||x>=info.width-3||y<3||y>=info.height-3)&&a>16) edge++;
  }
  if(maxX<0) throw new Error('Empty atlas cell');
  return {minX,minY,maxX,maxY,opaque,transparent,edge};
}
function bottomTip(data, info, crop) {
  let yTip=-1,xs=[];
  for(let y=0;y<info.height;y++)for(let x=0;x<info.width;x++){
    if(data[(y*info.width+x)*info.channels+info.channels-1]<128)continue;
    if(y>yTip){yTip=y;xs=[x];}else if(y===yTip)xs.push(x);
  }
  const x=(xs.reduce((a,b)=>a+b,0)/xs.length+.5-crop.left)/crop.width;
  return {x:Number(x.toFixed(6)),y:Number(((yTip+1-crop.top)/crop.height).toFixed(6))};
}
async function main(){
  const manifest={version:1,name:'책나눔 · 도트 대화 애셋',assetCount:31,
    textBaked:false,formats:['png','webp'],transparency:'alpha',
    palette:{paper:'#fff6e2',walnut:'#6a4327',sage:'#55765e',teal:'#4f9c8d',gold:'#d8b367'},
    notes:['실제 글자·이름·S/C 단축키는 DOM에서 표시합니다.','공개 말풍선에 대화 원문을 넣지 않습니다.','기존 캐릭터 그림을 재사용하며 아지트는 비공개 개인 방입니다.'],
    atlases:[],assets:[]};
  const report={passed:true,warnings:[],assets:[]};
  for(const group of groups){
    const source=path.join(ROOT,'source',group.atlas);
    const meta=await sharp(source).metadata();
    if(!meta.hasAlpha) throw new Error(`${group.atlas}: alpha channel missing`);
    manifest.atlases.push({file:`source/${group.atlas}`,width:meta.width,height:meta.height,columns:group.cols,rows:group.rows});
    for(let index=0;index<group.ids.length;index++){
      const name=group.ids[index],row=Math.floor(index/group.cols),column=index%group.cols;
      const isIcon=group.atlas==='ui-controls.png'&&index>=8;
      const category=isIcon?'icons':group.dir,prefix=isIcon?'icon':group.prefix;
      const cell={left:Math.round(column*meta.width/group.cols),top:Math.round(row*meta.height/group.rows),
        width:Math.round((column+1)*meta.width/group.cols)-Math.round(column*meta.width/group.cols),
        height:Math.round((row+1)*meta.height/group.rows)-Math.round(row*meta.height/group.rows)};
      const {data,info}=await sharp(source).extract(cell).ensureAlpha().raw().toBuffer({resolveWithObject:true});
      const bounds=alphaBounds(data,info),pad=4;
      const crop={left:Math.max(0,bounds.minX-pad),top:Math.max(0,bounds.minY-pad),
        width:Math.min(info.width,bounds.maxX+pad+1)-Math.max(0,bounds.minX-pad),
        height:Math.min(info.height,bounds.maxY+pad+1)-Math.max(0,bounds.minY-pad)};
      const sourceRect={left:cell.left+crop.left,top:cell.top+crop.top,width:crop.width,height:crop.height};
      const folder=path.join(ROOT,'assets',category);await fs.mkdir(folder,{recursive:true});
      const base=`assets/${category}/${name}`;
      const extracted=sharp(source).extract(sourceRect);
      await extracted.clone().png({compressionLevel:9}).toFile(path.join(ROOT,`${base}.png`));
      await extracted.clone().webp({lossless:true,effort:6}).toFile(path.join(ROOT,`${base}.webp`));
      const isRing=name==='selection-ring',isMarker=category==='markers',isFrame=category==='frames';
      const frameSize=name==='chat-panel'?{width:352,height:660}:name==='request-dialog'?{width:320,height:190}:{width:252,height:124};
      const display=isMarker?(isRing?{width:64,height:Math.round(64*crop.height/crop.width)}:{width:34,height:Math.round(34*crop.height/crop.width)}):isIcon?{width:24,height:24}:isFrame?frameSize:{width:112,height:44};
      const entry={id:`${prefix}-${name}`,name:LABELS[name],category,png:`${base}.png`,webp:`${base}.webp`,
        width:crop.width,height:crop.height,display,atlas:`source/${group.atlas}`,row,column,cell,sourceRect,
        anchor:isMarker&&!isRing?bottomTip(data,info,crop):isRing?{x:0.5,y:0.5}:{x:0,y:0},
        minimumHitArea:isMarker||isIcon||category==='buttons'?{width:44,height:44}:undefined};
      if(isFrame||category==='buttons'){
        const slice=Math.max(8,Math.min(isFrame?64:40,Math.floor(Math.min(crop.width,crop.height)*.3)));
        entry.nineSlice={top:slice,right:slice,bottom:slice,left:slice,cssBorderWidth:isFrame?16:10,fill:true};
      }
      if(category==='buttons'){
        entry.state=name.split('-').at(-1);
        entry.textColor=name.startsWith('primary-')?(entry.state==='pressed'?'#fffdf0':'#10170d'):'#493929';
      }
      manifest.assets.push(entry);
      const metrics={id:entry.id,cell,sourceRect,padding:{left:bounds.minX,top:bounds.minY,right:info.width-bounds.maxX-1,bottom:info.height-bounds.maxY-1},edgePixelsAlphaAbove16:bounds.edge,transparentFraction:bounds.transparent/(info.width*info.height),opaqueFraction:bounds.opaque/(info.width*info.height)};
      if(bounds.edge>0){report.warnings.push(`${entry.id}: ${bounds.edge} painted pixels touch atlas cell edge; verify against adjacent asset.`);report.passed=false;}
      report.assets.push(metrics);
    }
  }
  if(manifest.assets.length!==31) throw new Error('Expected 31 exported assets');
  const css=[`/* Auto-exported asset classes. Keep words and names as HTML text. */`,
    `.convo-art{display:block;object-fit:contain;image-rendering:pixelated;pointer-events:none}`,
    `.convo-marker{width:34px;height:auto}.convo-ring{width:64px;height:auto}.convo-icon{width:24px;height:24px}`,
    `.convo-frame{border:16px solid transparent;border-image-repeat:stretch;box-sizing:border-box;color:#4f3929;padding:20px;min-width:0}`,
    `.convo-button{min-width:96px;min-height:44px;border:10px solid transparent;border-image-repeat:stretch;box-sizing:border-box;padding:2px 10px;font:700 14px/1.3 system-ui,sans-serif;cursor:pointer;image-rendering:pixelated}`,
    `.convo-button:focus-visible{outline:3px solid #378b81;outline-offset:3px}.convo-button:disabled{cursor:default}`];
  for(const a of manifest.assets){
    if(a.nineSlice){const s=a.nineSlice;css.push(`.convo-${a.id}{border-image-source:url('${a.png}');border-image-slice:${s.top} ${s.right} ${s.bottom} ${s.left} fill}`);}
    else css.push(`.convo-${a.id}{content:url('${a.png}')}`);
  }
  for(const kind of ['primary','secondary']){
    for(const [state,pseudo] of [['default',''],['hover',':hover:not(:disabled)'],['pressed',':active:not(:disabled)'],['disabled',':disabled']]){
      const a=manifest.assets.find(a=>a.id===`button-${kind}-${state}`),s=a.nineSlice;
      css.push(`.convo-button--${kind}${pseudo}{border-image-source:url('${a.png}');border-image-slice:${s.top} fill;color:${a.textColor}}`);
    }
  }
  await fs.writeFile(path.join(ROOT,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
  await fs.writeFile(path.join(ROOT,'manifest.js'),'window.CONVERSATION_ASSETS = '+JSON.stringify(manifest)+';\n');
  await fs.writeFile(path.join(ROOT,'assets.css'),css.join('\n')+'\n');
  await fs.writeFile(path.join(ROOT,'spec','export-qa.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({assetCount:manifest.assets.length,png:31,webp:31,passed:report.passed,warnings:report.warnings}));
}
main().catch(e=>{console.error(e.stack);process.exitCode=1;});
